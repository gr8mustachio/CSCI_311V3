#include <stdlib.h>
#include<iostream>
#include<string>
#include<iomanip>
#include<stdio.h>
#include<cstdio>
#include<cmath>
using namespace std;

#include "bst.h"


int main(){

    BST numbers;
	int x;
    while(cin >> x){
		numbers.insert(x);
    }//while
	numbers.print_inorder();

    return 0;

}//main()
