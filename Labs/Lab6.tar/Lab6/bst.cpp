#include<iostream>
using namespace std;

#include "bst.h"

void BST::print_inorder(Tnode *cur){
        if(cur == NULL)
                return;
        print_inorder(cur->left);
        cout << cur->value << " ";
        print_inorder(cur->right);
}//print_inorder


void BST::clean(Tnode *cur){
        if(cur == NULL)
                return;
        clean(cur->left);
        clean(cur->right);
        delete cur;
}//clean()

bool BST::insert(Tnode* cur, int val){
       
     
                if(val < cur->value){
                        if(cur->left == NULL){
                                cur->left = new Tnode(val);
                                return true;
                                }
                        else
                                insert(cur->left, val);
                }//if 
                else if(val > cur->value){
                        if(cur->right == NULL){
                                cur->right = new Tnode(val);
                                return true;
                                }
                        else
                                insert(cur->right, val);
                }//else if
                else{
                        return false;

                        }
   
        return true;
}//insert()

