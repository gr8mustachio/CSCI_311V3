#include<iostream>
using namespace std;

#include "tnode.h"
#ifndef BST_H
#define BST_H

class BST{
        public:
                BST():  root(NULL) {};
                ~BST(){ clean(root); root = NULL; };
 
				bool insert(int val){ 
					if(root == NULL){
						root = new Tnode(val);
						return true;
					}else
						return insert(root, val); 
					return true;
				};
				void print_inorder(){ print_inorder(root);
                        cout << endl;
				};
		private:
				bool insert(Tnode* cur, int val);
				void print_inorder(Tnode *cur);
				Tnode *root = NULL;
				void clean(Tnode* cur);
};


#endif
