#include<iostream>
using namespace std;

#include "bst.h"

void BST::heightPrint(Tnode *cur){
	if(cur != NULL){
		heightPrint(cur->left);
		cout << cur->height << " ";
		heightPrint(cur->right);
	}

}
void BST::findPrint(Tnode *cur, string akey){
	if(cur != NULL){
		if(cur->key == akey){
			int asize = (int)(cur->value).size();
			for(int i = 0; i < asize ; i++)
				cout << (cur->value)[i] << " ";
			cout << endl;
			return;
		}else if(akey < cur->key)
			findPrint(cur->left, akey);
		else
			findPrint(cur->right, akey);
	}
}//findPrint()

void BST::print_inorder(Tnode *cur){
        if(cur == NULL)
                return;
        print_inorder(cur->left);
        cout << "(" << cur->key << "){";
		int asize = (int)(cur->value).size();
		for(int i = 0; i < asize; i++)
			cout << (cur->value)[i] << " " ;
		cout << "} ";
        print_inorder(cur->right);
}//print_inorder


void BST::clean(Tnode *cur){
        if(cur == NULL)
                return;
        clean(cur->left);
        clean(cur->right);
        delete cur;
}//clean()

void BST::insert(Tnode *cur, string akey, string aval){
               if(akey < cur->key){
                        if(cur->left == NULL){
                                cur->left = new Tnode(akey, aval);
                                return ;
                                }
                        else{
                                insert(cur->left, akey, aval);
								updateHeight(cur);
						}
                }//if 
                else if(akey > cur->key){
                        if(cur->right == NULL){
                                cur->right = new Tnode(akey, aval);
                                return ;
                                }
                        else{
                                insert(cur->right, akey, aval);
								updateHeight(cur);
						}
                }//else if
                else{
					(cur->value).push_back(aval);
                        return ;

                        }
        
      
}//insert()

