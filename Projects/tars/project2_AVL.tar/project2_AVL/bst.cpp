#include<iostream>
using namespace std;

#include "bst.h"

Tnode* BST::restoreBalance(Tnode* cur){
	if(cur == NULL)
		return cur;
								int bf = balanceFactor(cur);
								if(bf > 1){//left subtree is higher
									if(balanceFactor(cur->left) >= 0){
										cur = rightRotation(cur);//height is updated
									}//outside case
									else{
										cur->left = leftRotation(cur->left);
										cur = rightRotation(cur);
									}//inside case
								}//bf = 2
								else if(bf < -1){
									if(balanceFactor(cur->right) <= 0){
										cur = leftRotation(cur);
									}//outside case
									else{
										cur->right = rightRotation(cur->right);
										cur = leftRotation(cur);
									}
								}//if bf = -2
	return cur;
}
Tnode* BST::remove(Tnode* cur, string ak){
	if(cur == NULL)
		return NULL;
	if(ak < cur->key){
		cur->left = remove(cur->left, ak);
								
	}else if(ak > cur->key){
		cur->right = remove(cur->right, ak);

	}else{//found the key
		if(cur->left == NULL){
			Tnode* temp = cur->right;
			delete cur;
			return temp;
		}else if(cur->right == NULL){
			Tnode* temp = cur->left;
			delete cur;
			return temp;
		}else{
			Tnode *leftMost = getleftmost(cur->right);
			cur->key = leftMost->key;
			cur->value = leftMost->value;
			cur->right = remove(cur->right, leftMost->key);

		}//two children
	
	}//found key
	int bf = balanceFactor(cur);
	if(bf > 1 || bf < -1){//left subtree is higher
		cur = restoreBalance(cur);
	}//if bf = -2
	updateHeight(cur);
	return cur;
}//remove

Tnode* BST::getleftmost(Tnode* cur){
	if(cur == NULL)
		return NULL;
	if(cur->left == NULL)
		return cur;
	return getleftmost(cur->left);
}//getleftmost

void BST::printBF(Tnode *cur){
	if(cur != NULL){
		printBF(cur->left);
		int bf = balanceFactor(cur);
		cout << bf << " " ;
		printBF(cur->right);
	}//if
}//printBF

void BST::updateHeight(Tnode *cur){
	if(cur == NULL)
		return;
	int hl = getHeight(cur->left);
	int hr = getHeight(cur->right);
	cur->height = (hl > hr) ? (hl + 1) : (hr + 1);

}//updateHeight
				
int BST::balanceFactor(Tnode *cur){
	if(cur == NULL)
		return 0;
	
	return getHeight(cur->left) - getHeighthr(cur->right);
}
				
Tnode* BST::rightRotation(Tnode *cur){
	Tnode *L = cur->left;
	cur->left = L->right;
	updateHeight(cur);
	L->right = cur;
	updateHeight(L);
	return L;
}

Tnode* BST::leftRotation(Tnode *cur){
	Tnode *R = cur->right;
	cur->right = R->left;
	updateHeight(cur);
	R->left = cur;
	updateHeight(R);
	return R;
}

void BST::heightPrint(Tnode *cur){
	if(cur != NULL){
		heightPrint(cur->left);
		cout << cur->height << " ";
		heightPrint(cur->right);
	}

}
void BST::findPrint(Tnode *cur, string akey){
	if(cur != NULL){
		if(cur->key == akey){
			int asize = (int)(cur->value).size();
			for(int i = 0; i < asize ; i++)
				cout << (cur->value)[i] << " ";
			cout << endl;
			return;
		}else if(akey < cur->key)
			findPrint(cur->left, akey);
		else
			findPrint(cur->right, akey);
	}
}//findPrint()

void BST::print_inorder(Tnode *cur){
        if(cur == NULL)
                return;
        print_inorder(cur->left);
        cout << "(" << cur->key << "){";
		int asize = (int)(cur->value).size();
		for(int i = 0; i < asize; i++)
			cout << (cur->value)[i] << " " ;
		cout << "} ";
        print_inorder(cur->right);
}//print_inorder


void BST::clean(Tnode *cur){
        if(cur == NULL)
                return;
        clean(cur->left);
        clean(cur->right);
        delete cur;
}//clean()

Tnode* BST::insert(Tnode *cur, string akey, string aval){
               if(akey < cur->key){
                        if(cur->left == NULL){
                                cur->left = new Tnode(akey, aval);
                                }//if found place
                        else{
                                cur->left = insert(cur->left, akey, aval);
								
						}//else
						
                }//if 
                else if(akey > cur->key){
                        if(cur->right == NULL){
                                cur->right = new Tnode(akey, aval);
								updateHeight(cur);
                          
                                }
                        else{
                                cur->right = insert(cur->right, akey, aval);						
						}
						
                }//else if
                else{
					(cur->value).push_back(aval);
                       

                        }
	int bf = balanceFactor(cur);
	if(bf > 1 || bf < -1){//left subtree is higher
		cur = restoreBalance(cur);
	}//if bf = -2
	updateHeight(cur);
				return cur;
      
}//insert()

